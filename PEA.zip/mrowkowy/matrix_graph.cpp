//
// Created by kajp on 02.06.2024.
//

#include "matrix_graph.h"

#include <atomic>
#include <stdexcept>

matrix_graph::matrix_graph(bool const empty) {
    //where first vector is starting point and second is ending point
    //both vectors are always equal and size of vector is telling how many nodes are there
    // M_graph.push_back({false,false,true,true,false});
    // M_graph.push_back({true,false,true,true,true});
    // M_graph.push_back({false,true,false,true,true});
    // M_graph.push_back({true,false,false,false,true});
    // M_graph.push_back({true,false,false,false,false});

    if (!empty) {
        //-99999 is an indicator of not existing line
        M_graph.push_back({123, 100, 12, 10, 5});
        M_graph.push_back({90, 1, 98, 0, 9});
        M_graph.push_back({75, 64, 54, 4, 95});
        M_graph.push_back({37, 45, 18, 2, 120});
        M_graph.push_back({3, 0, 177, 200, 49});
    } else {
        M_graph.clear();
    }
}

matrix_graph::matrix_graph(int howmany_splots, int howmany_lines) {
    if (howmany_lines > howmany_splots * howmany_splots) throw std::logic_error("There can't be more lines than square of splots");
    if (howmany_lines < howmany_splots - 1) throw std::logic_error("graph won't be consistent, please add more lines");
    int i = 0;
    std::vector<int> tmp;
    for (int s = 0; s < howmany_splots; s++) {
        tmp.clear();
        for (int x = 0; x < howmany_splots; x++) {
            tmp.push_back(-99999);
        }
        M_graph.push_back(tmp);
    }
    std::vector<int> check;
    for (int l = 0; l < howmany_splots; l++) {
        check.push_back(l);
    }
    while (true) {
        for (int s = 0; s < howmany_splots; s++) {
            for (int x = 0; x < howmany_splots; x++) {
                if (i == howmany_lines) return;
                if (randomize(0, 3) == 3) {
                    for (int ch = 0; ch < check.size(); ch++) {
                        if (check[ch] == x) {
                            if (M_graph[s][x] == -99999 && x != s) {
                                i++;
                                check.erase(std::next(check.begin(), ch));
                                for (int e = 0; e < check.size(); e++) {
                                    if (check[e] == s && !check.empty()) {
                                        check.erase(std::next(check.begin(), e));
                                    }
                                }
                                M_graph[s][x] = randomize(0, 100000);
                            }
                        }
                    }
                    if (M_graph[s][x] == -99999 && x != s && check.empty()) {
                        i++;
                        M_graph[s][x] = randomize(0, 100000);
                    }
                }
            }
        }
    }
}

void matrix_graph::add_splot() {
    //-99999 is an indicator of not existing line
    std::vector<int> tmp;
    for (int i = 0; i < M_graph.size(); i++) {
        M_graph[i].push_back(-99999);
    }
    for (int i = 0; i < M_graph.size(); i++) {
        tmp.push_back(-99999);
    }
    M_graph.push_back(tmp);
}

void matrix_graph::add_splot(int const howmany_add) {
    //-99999 is an indicator of not existing line
    for (int i = 0; i < M_graph.size(); i++) {
        for (int k = 0; k < howmany_add; k++) {
            M_graph[i].push_back(-99999);
        }
    }
    int helper = M_graph.size();
    for (int j = 0; j < howmany_add; j++) {
        std::vector<int> tmp;
        for (int i = 0; i < howmany_add + helper; i++) {
            tmp.push_back(-99999);
        }
        M_graph.push_back(tmp);
    }
}

void matrix_graph::remove_splot(int const which) {
    if (which < 0 || which >= M_graph.size()) throw std::logic_error("There isn't any splot with choosen number");
    M_graph.erase(std::next(M_graph.begin(), which));
    int y = 0;
    while (y < M_graph.size()) {
        M_graph[y].erase(std::next(M_graph[y].begin(), which));
        y++;
    }
}

void matrix_graph::add_line(int const From_which_splot, int const To_which_splot, int const weight) {
    //column is starting splot, row is ending
    if (From_which_splot < 0 || From_which_splot >= M_graph.size()) throw std::logic_error("There isn't any splot with choosen number");
    if (To_which_splot < 0 || To_which_splot >= M_graph.size()) throw std::logic_error("There isn't any splot with choosen number");
    if (M_graph[To_which_splot][From_which_splot] == -99999) {
        M_graph[To_which_splot][From_which_splot] = weight;
        return;
    }
    throw std::logic_error("line between two splots already exists");
}

void matrix_graph::add_line(std::vector<std::vector<int> > lines) {
    for (int i = 0; i < lines.size(); i++) {
        add_line(lines[i][0], lines[i][1], lines[i][2]);
    }
}

void matrix_graph::add_line_or_replace(int const From_which_splot, int const To_which_splot, int const weight) {
    //column is starting splot, row is ending
    if (From_which_splot < 0 || From_which_splot >= M_graph.size()) throw std::logic_error("There isn't any splot with choosen number");
    if (To_which_splot < 0 || To_which_splot >= M_graph.size()) throw std::logic_error("There isn't any splot with choosen number");
    M_graph[To_which_splot][From_which_splot] = weight;
}

void matrix_graph::delete_line(int const From_which_splot, int const To_which_splot) {
    if (From_which_splot < 0 || From_which_splot >= M_graph.size()) throw std::logic_error("There isn't any splot with choosen number");
    if (To_which_splot < 0 || To_which_splot >= M_graph.size()) throw std::logic_error("There isn't any splot with choosen number");
    M_graph[To_which_splot][From_which_splot] = -99999;
}

void matrix_graph::show_lines(int From_which_splot) {
    if (From_which_splot < 0 || From_which_splot >= M_graph.size()) throw std::logic_error("There isn't any splot with choosen number");
    std::vector<int> lines;
    for (int i = 0; i < M_graph.size(); i++) {
        for (int j = 0; j < M_graph.size(); j++) {
            if (M_graph[i][j] != -99999) {
                if (i == From_which_splot || j == From_which_splot) lines.push_back(M_graph[i][j]);
            }
        }
    }
    std::sort(lines.begin(), lines.end());
    for (int i = 0; i < lines.size(); i++) {
        std::cout << lines[i];
        std::cout << std::endl;
    }
}

void matrix_graph::show_lines() {
    for (int i = 0; i < M_graph.size(); i++) {
        for (int j = 0; j < M_graph.size(); j++) {
            if (M_graph[i][j] != -99999) {
                std::cout << j << " -> " << i << " weight: " << M_graph[i][j] << std::endl;
            }
        }
    }
}

int matrix_graph::randomize(int const from, int const to) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> distr(from, to);
    return distr(gen);
}

void matrix_graph::smallest_tree(matrix_graph graph) {
    M_graph.clear();
    add_splot(graph.M_graph.size());
    struct Line {
        int w;
        int f;
        int s;

        Line(int weight, int first_splot, int second_splot) {
            w = weight;
            f = first_splot, s = second_splot;
        }

        bool operator<(Line &second) const {
            if (this->w < second.w) return true;
            return false;
        }
    };
    std::vector<Line> lines;
    for (int i = 0; i < graph.M_graph.size(); i++) {
        for (int j = 0; j < graph.M_graph.size(); j++) {
            if (graph.M_graph[i][j] != -99999) {
                lines.push_back({graph.M_graph[i][j], i, j});
            }
        }
    }
    std::sort(lines.begin(), lines.end());
    matrix_graph tmp{true};
    tmp.add_splot(graph.M_graph.size());
    int k = 0, test = 0;
    while (true) {
        if(k==lines.size()) throw std::logic_error("something went wrong in smallest tree");
        if (test == graph.M_graph.size() - 1) return;
        if (lines[k].f != lines[k].s) {
            if (!do_exists(lines[k].f) || !do_exists(lines[k].s)) {
                M_graph[lines[k].f][lines[k].s] = lines[k].w;
                test++;
            } else {
                if (!do_exists_line(lines[k].f, lines[k].s) && how_many_lines(lines[k].f) <= 1 && how_many_lines(lines[k].s) <= 1 && !is_it_cycle(lines[k].f, lines[k].s)) {
                    M_graph[lines[k].f][lines[k].s] = lines[k].w;
                    test++;
                }
            }
        }
        k++;
    }
}

bool matrix_graph::do_exists(int Splot_Number) {
    for (int j = 0; j < M_graph.size(); j++) {
        if (M_graph[Splot_Number][j] != -99999) {
            return true;
        }
        if (M_graph[j][Splot_Number] != -99999) {
            return true;
        }
    }
    return false;
}

bool matrix_graph::do_exists_line(int const from, int const to) {
    if (M_graph[to][from] != -99999) return true;
    if (M_graph[from][to] != -99999) return true;
    return false;
}

bool matrix_graph::do_exists_line_directed(int const from, int const to) {
    if (M_graph[from][to] != -99999) return true;
    return false;
}

int matrix_graph::how_many_lines(int Splot_Number) {
    int counter = 0;
    for (int i = 0; i < M_graph.size(); i++) {
        for (int j = 0; j < M_graph.size(); j++) {
            if (M_graph[i][j] != -99999) {
                if (i == Splot_Number || j == Splot_Number) counter++;
            }
        }
    }
    return counter;
}

bool matrix_graph::is_it_cycle(int from, int to) {
    matrix_graph help{true};
    help.M_graph = M_graph;
    int tmp_f = from;
    int tmp_f_p = -1;
    int i;
    help.add_line(from, to, 12345);
    int check=0;
    while (!help.empty()) {
        if(check==3) return true;
        if(tmp_f==from) check++;
        for (i = 0; i < M_graph.size(); i++) {
            if (tmp_f_p == -1) {
                if (help.do_exists_line(tmp_f, i) && tmp_f_p != i && i!=to) {
                    tmp_f_p = tmp_f;
                    tmp_f = i;
                    break;
                }
            } else {
                if (help.do_exists_line(tmp_f, i) && tmp_f_p != i) {
                    tmp_f_p = tmp_f;
                    tmp_f = i;
                    break;
                }
            }
        }
        if (i == M_graph.size()) {
            if (help.do_exists_line(tmp_f, tmp_f_p)) {
                help.delete_line(tmp_f, tmp_f_p);
                help.delete_line(tmp_f_p, tmp_f);
                tmp_f = tmp_f_p;
                check=0;
            } else {
                return false;
            }
        }
    }
    if (tmp_f == from && tmp_f_p == to) return false;
    if (tmp_f_p == from && tmp_f == to) return false;
    return false;
}

bool matrix_graph::empty() {
    for (int i = 0; i < M_graph.size(); i++) {
        for (int j = 0; j < M_graph.size(); j++) {
            if (M_graph[i][j] != -99999) return false;
        }
    }
    return true;
}

int matrix_graph::weight_of_choosen_line(int First_Splot, int Second_Splot) {
    if(do_exists_line(First_Splot,Second_Splot)) {
        return M_graph[First_Splot][Second_Splot];
    }
    return -99999;
}
