#include <iostream>
#include <fstream>
#include <chrono>
#include <queue>
#include "matrix_graph.h"
#include <filesystem>

bool czy_jest(std::vector<int> do_przeszukania, int to);

int waga_linii_miedzy_punktami(int punkt_1, int punkt_2, matrix_graph &lul);

void funkcja_szukajaca_drogi(matrix_graph graf_do_przeszukania, int ilosc_wierzcholkow,std::vector<int>pomoc_kopia,int pom_kopia, int punkt_startowy, int &naj, std::vector<int> &najlepszy) {
    while (true) {
        int wybor = -99999;
        if (pomoc_kopia.size() == ilosc_wierzcholkow) break;
        for (int j = 0; j < ilosc_wierzcholkow; j++) {
            if (((pomoc_kopia.empty() && graf_do_przeszukania.do_exists_line(punkt_startowy, j)) || (!pomoc_kopia.empty() && graf_do_przeszukania.do_exists_line(pomoc_kopia[pomoc_kopia.size() - 1], j) && !czy_jest(pomoc_kopia, j))) &&
                punkt_startowy != j || pomoc_kopia.size() == ilosc_wierzcholkow - 1 && graf_do_przeszukania.do_exists_line(pomoc_kopia[pomoc_kopia.size() - 1], j) && !czy_jest(pomoc_kopia, j)) {
                if (wybor == -99999) {
                    wybor = j;
                } else {
                    if (pomoc_kopia.empty()) {
                        if (waga_linii_miedzy_punktami(punkt_startowy, j, graf_do_przeszukania) < waga_linii_miedzy_punktami(punkt_startowy, wybor, graf_do_przeszukania)) {
                            wybor = j;
                        }
                    } else if (waga_linii_miedzy_punktami(pomoc_kopia[pomoc_kopia.size() - 1], j, graf_do_przeszukania) < waga_linii_miedzy_punktami(pomoc_kopia[pomoc_kopia.size() - 1], wybor, graf_do_przeszukania)) {
                        wybor = j;
                    } else {
                    }
                }
            }
        }
        if (wybor == -99999) break;
        if (pomoc_kopia.empty()) {
            pom_kopia = pom_kopia + waga_linii_miedzy_punktami(wybor, punkt_startowy, graf_do_przeszukania);
            pomoc_kopia.push_back(wybor);
        } else {
            pom_kopia = pom_kopia + waga_linii_miedzy_punktami(wybor, pomoc_kopia[pomoc_kopia.size() - 1], graf_do_przeszukania);
            pomoc_kopia.push_back(wybor);
        }
        //sprawdzanie czy obszedł wszystkie punkty i wrócił na początek
        if (pomoc_kopia[pomoc_kopia.size() - 1] == 0 && pomoc_kopia.size() == ilosc_wierzcholkow) {
            if (pom_kopia < naj) {
                naj = pom_kopia;
                najlepszy = pomoc_kopia;
            }
        }
        //w zasadzie te warunki sa takie same jak powyzej (te dlugie w pierun) ale rozbite na 3
        for (int j = 0; j < punkt_startowy; j++) {
            if (pomoc_kopia.size()<=1 && graf_do_przeszukania.do_exists_line(punkt_startowy, j) && j != punkt_startowy && !czy_jest(pomoc_kopia, j)) {
                if (waga_linii_miedzy_punktami(punkt_startowy, j, graf_do_przeszukania) == waga_linii_miedzy_punktami(punkt_startowy, wybor, graf_do_przeszukania)) {
                    funkcja_szukajaca_drogi(graf_do_przeszukania, ilosc_wierzcholkow, pomoc_kopia, pom_kopia, j, naj,najlepszy);
                }
            } else if (pomoc_kopia.size()>1) {
                if (graf_do_przeszukania.do_exists_line(pomoc_kopia[pomoc_kopia.size() - 2], j) && j != punkt_startowy && !czy_jest(pomoc_kopia, j)) {
                    if (waga_linii_miedzy_punktami(pomoc_kopia[pomoc_kopia.size() - 2], j, graf_do_przeszukania) == waga_linii_miedzy_punktami(pomoc_kopia[pomoc_kopia.size() - 2], wybor, graf_do_przeszukania)) {
                        funkcja_szukajaca_drogi(graf_do_przeszukania, ilosc_wierzcholkow, pomoc_kopia, pom_kopia, j, naj,najlepszy);
                    }
                } else {
                    if (pomoc_kopia.size() == ilosc_wierzcholkow - 1 && graf_do_przeszukania.do_exists_line(pomoc_kopia[pomoc_kopia.size() - 2], j) && !czy_jest(pomoc_kopia, j)) {
                        if (waga_linii_miedzy_punktami(pomoc_kopia[pomoc_kopia.size() - 2], j, graf_do_przeszukania) == waga_linii_miedzy_punktami(pomoc_kopia[pomoc_kopia.size() - 2], wybor, graf_do_przeszukania)) {
                            funkcja_szukajaca_drogi(graf_do_przeszukania, ilosc_wierzcholkow, pomoc_kopia, pom_kopia, j, naj,najlepszy);
                        }
                    }
                }
            }
        }
    }
}

void random (matrix_graph graf_do_przeszukania, int ilosc_wierzcholkow,std::vector<int>pomoc_kopia, int &naj, std::vector<int> &najlepszy, int opt, int czas_dla_programu_w_s) {
    auto start = std::chrono::high_resolution_clock::now();
    int i;
        while (naj!=opt) {
            auto start_czesc = std::chrono::high_resolution_clock::now();
            int n=0,pom=0;
            int punkt_startowy=rand()%ilosc_wierzcholkow;
            pomoc_kopia.clear();
            while (n<15) {
                i = rand() % ilosc_wierzcholkow;
                while (!pomoc_kopia.empty() && pomoc_kopia[pomoc_kopia.size() - 1] == i) {
                    i = rand() % ilosc_wierzcholkow;
                }
                while(pomoc_kopia.size()!=ilosc_wierzcholkow-1&&i==punkt_startowy) {
                    i=rand()%ilosc_wierzcholkow;
                }
                if ((pomoc_kopia.empty() && graf_do_przeszukania.do_exists_line(punkt_startowy, i)) || (!pomoc_kopia.empty() && graf_do_przeszukania.do_exists_line(pomoc_kopia[pomoc_kopia.size() - 1], i) && !czy_jest(pomoc_kopia, i))) {
                    if (pomoc_kopia.empty()) pom = pom + waga_linii_miedzy_punktami(i, punkt_startowy, graf_do_przeszukania);
                    else {
                        pom = pom + waga_linii_miedzy_punktami(i, pomoc_kopia[pomoc_kopia.size() - 1], graf_do_przeszukania);
                    }
                    pomoc_kopia.push_back(i);
                }else {
                    n++;
                }
                //sprawdzanie czy obszedł wszystkie punkty i wrócił na początek
                if (!pomoc_kopia.empty()&&pomoc_kopia[pomoc_kopia.size()-1] == punkt_startowy && pomoc_kopia.size() == ilosc_wierzcholkow) {
                    if (pom < naj) {
                        naj = pom;
                        najlepszy = pomoc_kopia;
                        break;
                    }
                }
            }
            auto teraz = std::chrono::high_resolution_clock::now();
            auto czas_trwania_programu = std::chrono::duration_cast<std::chrono::seconds>(teraz - start);
            if (czas_trwania_programu.count() >= czas_dla_programu_w_s ) {
                break;
            }
        }
}

int dolna_granica_mst(matrix_graph &graf, int ilosc_wierzcholkow) {
    // Algorytm Prima do wyznaczenia MST
    std::vector<bool> visited(ilosc_wierzcholkow, false);
    std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, std::greater<>> pq;

    // Zaczynamy od pierwszego wierzchołka
    visited[0] = true;
    for (int i = 0; i < ilosc_wierzcholkow; ++i) {
        int waga = waga_linii_miedzy_punktami(0, i,graf);
        if (waga != -99999) {
            pq.push({waga, i});
        }
    }

    int mst_weight = 0;
    while (!pq.empty()) {
        auto [waga, v] = pq.top();
        pq.pop();

        if (visited[v]) continue;

        visited[v] = true;
        mst_weight += waga;

        for (int i = 0; i < ilosc_wierzcholkow; ++i) {
            int next_waga = waga_linii_miedzy_punktami(v, i,graf);
            if (!visited[i] && next_waga != -99999) {
                pq.push({next_waga, i});
            }
        }
    }

    return mst_weight;
}


// Obliczanie błędu bezwzględnego jako liczby
int blad_bezwzgledny(int wynik, int optymalny) {
    return abs(wynik - optymalny);
}

// Obliczanie błędu bezwzględnego jako procent
double blad_bezwzgledny_procent(int wynik, int optymalny) {
    return (static_cast<double>(abs(wynik - optymalny)) / optymalny) * 100.0;
}

// Obliczanie błędu względnego jako liczby
int blad_wzgledny(int wynik, int dolna_granica) {
    return wynik - dolna_granica;
}

// Obliczanie błędu względnego jako procent
double blad_wzgledny_procent(int wynik, int dolna_granica) {
    return (static_cast<double>(wynik - dolna_granica) / dolna_granica) * 100.0;
}

struct Mrowka {
    std::vector<int> sciezka;
    double dlugosc_sciezki = std::numeric_limits<double>::max();
};

class AlgorytmMrowkowy {
    matrix_graph &graf;
    int liczba_wierzcholkow;
    int liczba_mrowek;
    double alfa;
    double beta;
    double stopien_parowania;
    std::string metoda_rozkladu;
    std::vector<std::vector<double>> feromon;
    std::vector<std::vector<double>> widocznosc;

public:
    AlgorytmMrowkowy(matrix_graph &g, int liczba_wierzcholkow, int mrowki, double a, double b, double parowanie, const std::string &metoda)
        : graf(g), liczba_wierzcholkow(liczba_wierzcholkow), liczba_mrowek(mrowki), alfa(a), beta(b), stopien_parowania(parowanie), metoda_rozkladu(metoda) {
        inicjalizuj_feromon();
        inicjalizuj_widocznosc();
    }

    void inicjalizuj_feromon() {
        feromon = std::vector<std::vector<double>>(liczba_wierzcholkow, std::vector<double>(liczba_wierzcholkow, 1.0));
    }

    void inicjalizuj_widocznosc() {
        widocznosc = std::vector<std::vector<double>>(liczba_wierzcholkow, std::vector<double>(liczba_wierzcholkow, 0.0));
        for (int i = 0; i < liczba_wierzcholkow; ++i) {
            for (int j = 0; j < liczba_wierzcholkow; ++j) {
                int waga = waga_linii_miedzy_punktami(i, j, graf);
                if (waga != -99999) {
                    widocznosc[i][j] = 1.0 / waga;
                }
            }
        }
    }

    std::vector<int> rozwiaz(int limit_czasu_ms, int funkcja, int optymalne, int &waga) {
        std::vector<int> najlepsza_sciezka;
        double najlepsza_dlugosc = std::numeric_limits<double>::max();

        // Znajdź początkowe rozwiązanie
        std::vector<int> poczatkowa_sciezka;
        int poczatkowa_dlugosc = INT_MAX;
        if (funkcja == 0) {
            int pocz=0;
            while(poczatkowa_dlugosc==INT_MAX&&pocz<liczba_wierzcholkow) {
                funkcja_szukajaca_drogi(graf, liczba_wierzcholkow, {}, 0, pocz, poczatkowa_dlugosc, poczatkowa_sciezka);
                pocz++;
            }
        } else {
            random(graf, liczba_wierzcholkow, {}, poczatkowa_dlugosc, poczatkowa_sciezka, optymalne, funkcja);
        }
        if(poczatkowa_sciezka.empty()) throw std::logic_error("Brak sciezki poczatkowej, jesli korzystasz z algorytmu losowego ustaw wiecej czasu dla niego");
        najlepsza_sciezka = poczatkowa_sciezka;
        najlepsza_dlugosc = poczatkowa_dlugosc;

        auto start_czas = std::chrono::high_resolution_clock::now();
        auto ostatnia_poprawa_czas = start_czas;

        while (true) {
            std::vector<Mrowka> mrowki(liczba_mrowek);

            for (auto &mrowka : mrowki) {
                std::vector<bool> odwiedzone(liczba_wierzcholkow, false);
                mrowka.sciezka.push_back(0); // Startujemy z wierzchołka 0
                odwiedzone[0] = true;

                for (int krok = 1; krok < liczba_wierzcholkow; ++krok) {
                    int obecny = mrowka.sciezka.back();
                    double suma_prawdopodobienstw = 0.0;
                    std::vector<double> prawdopodobienstwa(liczba_wierzcholkow, 0.0);

                    // Oblicz prawdopodobieństwa wyboru następnego wierzchołka
                    for (int nastepny = 0; nastepny < liczba_wierzcholkow; ++nastepny) {
                        if (!odwiedzone[nastepny]) {
                            prawdopodobienstwa[nastepny] = pow(feromon[obecny][nastepny], alfa) * pow(widocznosc[obecny][nastepny], beta);
                            suma_prawdopodobienstw += prawdopodobienstwa[nastepny];
                        }
                    }

                    // Wybierz następny wierzchołek na podstawie prawdopodobieństwa
                    double losowa = static_cast<double>(rand()) / RAND_MAX * suma_prawdopodobienstw;
                    double skumulowane = 0.0;
                    int wybrany = -1;
                    for (int nastepny = 0; nastepny < liczba_wierzcholkow; ++nastepny) {
                        if (!odwiedzone[nastepny]) {
                            skumulowane += prawdopodobienstwa[nastepny];
                            if (skumulowane >= losowa) {
                                wybrany = nastepny;
                                break;
                            }
                        }
                    }

                    if (wybrany != -1) {
                        mrowka.sciezka.push_back(wybrany);
                        odwiedzone[wybrany] = true;
                    }
                }

                // Zamknij trasę
                mrowka.sciezka.push_back(mrowka.sciezka[0]);

                // Oblicz długość ścieżki
                mrowka.dlugosc_sciezki = 0;
                for (size_t i = 0; i < mrowka.sciezka.size() - 1; ++i) {
                    int waga = waga_linii_miedzy_punktami(mrowka.sciezka[i], mrowka.sciezka[i + 1], graf);
                    if (waga == -99999) {
                        mrowka.dlugosc_sciezki = std::numeric_limits<double>::max();
                        break;
                    }
                    mrowka.dlugosc_sciezki += waga;
                }

                if (mrowka.dlugosc_sciezki < najlepsza_dlugosc) {
                    najlepsza_dlugosc = mrowka.dlugosc_sciezki;
                    najlepsza_sciezka = mrowka.sciezka;
                    ostatnia_poprawa_czas = std::chrono::high_resolution_clock::now();
                }

                if (najlepsza_dlugosc == optymalne) {
                   // std::cout << "Znaleziono optymalne rozwiązanie." << std::endl;
                    waga = static_cast<int>(najlepsza_dlugosc);
                    return najlepsza_sciezka;
                }
            }

            aktualizuj_feromon(mrowki);

            auto aktualny_czas = std::chrono::high_resolution_clock::now();
            auto czas_bez_poprawy = std::chrono::duration_cast<std::chrono::milliseconds>(aktualny_czas - ostatnia_poprawa_czas);

            if (czas_bez_poprawy.count() >= limit_czasu_ms) {
                waga = static_cast<int>(najlepsza_dlugosc);
                break;
            }
        }

        return najlepsza_sciezka;
    }

    void aktualizuj_feromon(const std::vector<Mrowka> &mrowki) {
        for (int i = 0; i < liczba_wierzcholkow; ++i) {
            for (int j = 0; j < liczba_wierzcholkow; ++j) {
                feromon[i][j] *= (1.0 - stopien_parowania);
            }
        }

        for (const auto &mrowka : mrowki) {
            double wklad = (metoda_rozkladu == "CAS") ? 1.0 / mrowka.dlugosc_sciezki : 1.0;

            for (size_t i = 0; i < mrowka.sciezka.size() - 1; ++i) {
                int z = mrowka.sciezka[i];
                int do_ = mrowka.sciezka[i + 1];

                if (metoda_rozkladu == "DAS") {
                    wklad = 0.1; // Stała wartość dla DAS
                }

                feromon[z][do_] += wklad;
                feromon[do_][z] += wklad;
            }
        }
    }
};


int main() {
    try {
        auto start_programu = std::chrono::high_resolution_clock::now();
        //=========================================
        //int sp = 14, lin =45 ;//całkowicie losowy
        //matrix_graph graf{sp, lin};
        //=========================================

        //=========================================
        std::ifstream odczytus("conf.txt");
        int macierz=0;
        int limit_czasu=0;
        std::string CAS_DAS;
        int metoda=0;
        double alfa=0,beta=0,par=0;
        std::string odczytany_wyraz,nazwa_danych;
        while(true) {
            odczytus>>odczytany_wyraz;
            if(odczytany_wyraz[0]=='/'&&odczytany_wyraz[1]=='/') continue;
            if(odczytany_wyraz[0]=='!') break;
            if(odczytany_wyraz[0]=='M') {
                odczytus>>macierz;
                continue;
            }
            if(odczytany_wyraz[0]=='#') {
                odczytus>>limit_czasu;
            }
            if(odczytany_wyraz[0]=='&') {
                odczytus>>CAS_DAS;
            }
            if(odczytany_wyraz[0]=='@') {
                odczytus>>metoda;
            }
            if(odczytany_wyraz[0]=='a') {
                odczytus>>alfa;
            }
            if(odczytany_wyraz[0]=='b') {
                odczytus>>beta;
            }
            if(odczytany_wyraz[0]=='P') {
                odczytus>>par;
            }
            if(odczytany_wyraz.size()>4&&odczytany_wyraz[odczytany_wyraz.size()-1]=='t'&&odczytany_wyraz[odczytany_wyraz.size()-3]=='t') {
                nazwa_danych=odczytany_wyraz;
            }
        }
        if(par==0||alfa==0||beta==0) throw std::logic_error("Blednie podana wartosc jednego lub wiecej parametrow");
        if(metoda<0) throw std::logic_error("Blednie podana wartosc dla wybrania funkcji rozwiazania poczatkowego");
        if(limit_czasu==0) throw std::logic_error("brak ustalonego limitu czasu");
        matrix_graph graf(true);
        int sp=-99999;
        std::ifstream odczyt(nazwa_danych);//pliki wrzucać do cmake'a
        int optymalne;
        odczyt>>optymalne;
        if(macierz==1) {
            odczyt>>sp;
            graf.add_splot(sp);
            int punkt2=0,waga=0,n=0;
            while(n<=sp*sp) {
                for(int punkt1=0;punkt1<sp;punkt1++) {
                    odczyt>>waga;
                    if(waga!=-99999) {
                        graf.add_line(punkt1,punkt2,waga);
                    }
                }
                punkt2++;
                n++;
            }
        }else {
            odczyt>>sp;
            graf.add_splot(sp);
            std::vector<std::pair<int, int>> koordynaty(sp);
            while(true){
                int id, x, y;
                odczyt >> id;
                if(id==-99999) break;
                odczyt >> x >> y;
                koordynaty[id - 1] = {x, y};
            }
            for (int i = 0; i < sp; ++i) {
                for (int j = i + 1; j < sp; ++j) {
                    int x1 = koordynaty[i].first, y1 = koordynaty[i].second;
                    int x2 = koordynaty[j].first, y2 = koordynaty[j].second;

                    double dystans = std::sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
                    int zaaokroglony_dystans = static_cast<int>(std::round(dystans));
                    graf.add_line(i,j,zaaokroglony_dystans);
                }
            }
        }
        //=========================================
        if (sp == -99999) throw std::logic_error("brak pliku albo zly format");; //zabezpieczenie przed próbą włączenia programu na pustym grafie
        std::vector<int> najlepszy;
        int naj = INT_MAX;

        AlgorytmMrowkowy taki(graf,sp,sp,1.0,3.0,0.5,CAS_DAS);

        najlepszy = taki.rozwiaz(limit_czasu,metoda,optymalne,naj);

        if (naj == INT_MAX) printf("nie istnieje nawet 1 droga pozwalajaca przejsc przez wszystkie punkty");
        else {
            if(sp<=16) {
                printf("\nnajkrotsza droga to: ");
                for (int b = 0; b < najlepszy.size(); b++) {
                    printf("%d ", najlepszy[b]);
                }
            }
            printf("\ndroga ta wazy: %d ", naj);
            auto czas_teraz = std::chrono::high_resolution_clock::now();
            auto czas = std::chrono::duration_cast<std::chrono::milliseconds>(czas_teraz - start_programu);
            long long int czas_trwania_programu=czas.count();
            czas_trwania_programu-=metoda*1000;
            printf("\nAlgorytm ten trwal: %lld ms \n", czas_trwania_programu);
            std::cout<<"Uzyty plik z danymi to: "<<nazwa_danych;
            if(macierz==1) printf("\nSczytano z macierzy");
            if(macierz==0) printf("\nSczytano linia po linii");
            printf("\nUstawiony limit czasu to: %d ms",limit_czasu);
            printf("\nUstawione parametry wynosza po kolei: Alfa = %f, Beta = %f, P = %f",alfa,beta,par);
            if(metoda==0) printf("\nUzyto algorytmu NN jako rozwiazanie poczatkowe");
            else {
                printf("\nUzyto algorytmu losowego jako rozwiazanie poczatkowe, czas wykonywania losowego zostal ustalony na: %d s",metoda);
            }
            std::cout<<"\nUzyto feromonu: "<<CAS_DAS;
            printf("\nOptymalna sciezka to: %d",optymalne);

            int dolna_granica=dolna_granica_mst(graf,sp);
            int blad_bezwzgledny_wynik = blad_bezwzgledny(naj, optymalne);
            double blad_bezwzgledny_proc = blad_bezwzgledny_procent(naj, optymalne);
            int blad_wzgledny_wynik = blad_wzgledny(naj, dolna_granica);
            double blad_wzgledny_proc = blad_wzgledny_procent(naj, dolna_granica);

            printf("\nDolna Granica : %d", dolna_granica);
            printf("\nBlad bezwzgledny (liczba): %d", blad_bezwzgledny_wynik);
            printf("\nBlad bezwzgledny (procent): %.2f%%", blad_bezwzgledny_proc);
            printf("\nBlad wzgledny (liczba): %d", blad_wzgledny_wynik);
            printf("\nBlad wzgledny (procent): %.2f%%", blad_wzgledny_proc);

            if(!std::filesystem::exists("plik_wyjsciowy.csv")) {
                std::ofstream wyjscie;
                wyjscie.open ("plik_wyjsciowy.csv");
                wyjscie<<"wielkosc instancji;"<<"czas wykonywania [ms];"<<"waga znalezionej sciezki;"<<"Blad bezwgledny %;"<<"Blad wzgledny %;"<<"alfa;"<<"beta;"<<"parowanie;"<<"feromon;"<<"zuzycie RAM [%];"<<std::endl;
                wyjscie<<sp<<";"<<czas_trwania_programu<<";"<<naj<<";"<<blad_bezwzgledny_proc<<";"<<blad_wzgledny_proc<<";"<<alfa<<";"<<beta<<";"<<par<<";"<<CAS_DAS<<std::endl;
                wyjscie.close();
            }else {
                std::ofstream wyjscie;
                wyjscie.open ("plik_wyjsciowy.csv",std::ios::app);
                wyjscie<<sp<<";"<<czas_trwania_programu<<";"<<naj<<";"<<blad_bezwzgledny_proc<<";"<<blad_wzgledny_proc<<";"<<alfa<<";"<<beta<<";"<<par<<";"<<CAS_DAS<<std::endl;
                wyjscie.close();
            }
        }
    } catch (std::logic_error &e) {
        std::cout << e.what();
    }

    return 0;
}

bool czy_jest(std::vector<int> do_przeszukania, int to) {
    for (int i = 0; i < do_przeszukania.size(); i++) {
        if (do_przeszukania[i] == to) return true;
    }
    return false;
}

int waga_linii_miedzy_punktami(int punkt_1, int punkt_2, matrix_graph &lul) {
    if (lul.weight_of_choosen_line(punkt_1, punkt_2) != -99999 &&
        lul.weight_of_choosen_line(punkt_2, punkt_1) != -99999) {
        if (lul.weight_of_choosen_line(punkt_1, punkt_2) < lul.weight_of_choosen_line(punkt_2, punkt_1)) {
            return lul.weight_of_choosen_line(punkt_1, punkt_2);
        }
        return lul.weight_of_choosen_line(punkt_2, punkt_1);
    }
    if (lul.weight_of_choosen_line(punkt_1, punkt_2) != -99999) return lul.weight_of_choosen_line(punkt_1, punkt_2);
    if (lul.weight_of_choosen_line(punkt_2, punkt_1) != -99999) return lul.weight_of_choosen_line(punkt_2, punkt_1);
    return -99999;
}
