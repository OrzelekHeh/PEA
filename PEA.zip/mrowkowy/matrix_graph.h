//
// Created by kajp on 02.06.2024.
//

#ifndef GRAPH_H
#define GRAPH_H
#include <vector>
#include <algorithm>
#include <iostream>
#include <random>
class matrix_graph {
private:

    std::vector<std::vector<int> > M_graph;
public:
    explicit matrix_graph(bool empty);
    matrix_graph(int howmany_splots,int howmany_lines);//random graph
    void add_splot();
    void add_splot(int howmany_add);
    void remove_splot(int which);
    void add_line(int From_which_splot, int To_which_splot, int weight);
    void add_line(std::vector<std::vector<int>> line);
    void add_line_or_replace(int From_which_splot, int To_which_splot, int weight);
    void delete_line(int From_which_splot, int To_which_splot);
    void show_lines (int From_which_splot);
    void show_lines();
    static int randomize(int from, int to);
    void smallest_tree(matrix_graph graph);
    bool do_exists(int Splot_Number);//return a true when chosen splot has a line connected to it
    bool do_exists_line(int from, int to);//return true when line exists between two choosen splots regardless of direction
    bool do_exists_line_directed(int from, int to);//return true when line exists between two choosen splots with choosen direction
    bool is_it_cycle(int from, int to); //return true when this new line will create a cycle
    bool empty();
    int how_many_lines(int Splot_Number);//return number of lines connected to a splot
    int weight_of_choosen_line(int First_Splot,int Second_Splot);//return weight of choosen line
};


#endif //GRAPH_H
