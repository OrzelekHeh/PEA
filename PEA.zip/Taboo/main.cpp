#include <iostream>
#include <fstream>
#include <chrono>
#include <queue>
#include "matrix_graph.h"
#include <filesystem>

bool czy_jest(std::vector<int> do_przeszukania, int to);

int waga_linii_miedzy_punktami(int punkt_1, int punkt_2, matrix_graph &lul);

void funkcja_szukajaca_drogi(matrix_graph graf_do_przeszukania, int ilosc_wierzcholkow,std::vector<int>pomoc_kopia,int pom_kopia, int punkt_startowy, int &naj, std::vector<int> &najlepszy) {
    while (true) {
        int wybor = -99999;
        if (pomoc_kopia.size() == ilosc_wierzcholkow) break;
        for (int j = 0; j < ilosc_wierzcholkow; j++) {
            if (((pomoc_kopia.empty() && graf_do_przeszukania.do_exists_line(punkt_startowy, j)) || (!pomoc_kopia.empty() && graf_do_przeszukania.do_exists_line(pomoc_kopia[pomoc_kopia.size() - 1], j) && !czy_jest(pomoc_kopia, j))) &&
                punkt_startowy != j || pomoc_kopia.size() == ilosc_wierzcholkow - 1 && graf_do_przeszukania.do_exists_line(pomoc_kopia[pomoc_kopia.size() - 1], j) && !czy_jest(pomoc_kopia, j)) {
                if (wybor == -99999) {
                    wybor = j;
                } else {
                    if (pomoc_kopia.empty()) {
                        if (waga_linii_miedzy_punktami(punkt_startowy, j, graf_do_przeszukania) < waga_linii_miedzy_punktami(punkt_startowy, wybor, graf_do_przeszukania)) {
                            wybor = j;
                        }
                    } else if (waga_linii_miedzy_punktami(pomoc_kopia[pomoc_kopia.size() - 1], j, graf_do_przeszukania) < waga_linii_miedzy_punktami(pomoc_kopia[pomoc_kopia.size() - 1], wybor, graf_do_przeszukania)) {
                        wybor = j;
                    } else {
                    }
                }
            }
        }
        if (wybor == -99999) break;
        if (pomoc_kopia.empty()) {
            pom_kopia = pom_kopia + waga_linii_miedzy_punktami(wybor, punkt_startowy, graf_do_przeszukania);
            pomoc_kopia.push_back(wybor);
        } else {
            pom_kopia = pom_kopia + waga_linii_miedzy_punktami(wybor, pomoc_kopia[pomoc_kopia.size() - 1], graf_do_przeszukania);
            pomoc_kopia.push_back(wybor);
        }
        //sprawdzanie czy obszedł wszystkie punkty i wrócił na początek
        if (pomoc_kopia[pomoc_kopia.size() - 1] == 0 && pomoc_kopia.size() == ilosc_wierzcholkow) {
            if (pom_kopia < naj) {
                naj = pom_kopia;
                najlepszy = pomoc_kopia;
            }
        }
        //w zasadzie te warunki sa takie same jak powyzej (te dlugie w pierun) ale rozbite na 3
        for (int j = 0; j < punkt_startowy; j++) {
            if (pomoc_kopia.size()<=1 && graf_do_przeszukania.do_exists_line(punkt_startowy, j) && j != punkt_startowy && !czy_jest(pomoc_kopia, j)) {
                if (waga_linii_miedzy_punktami(punkt_startowy, j, graf_do_przeszukania) == waga_linii_miedzy_punktami(punkt_startowy, wybor, graf_do_przeszukania)) {
                    funkcja_szukajaca_drogi(graf_do_przeszukania, ilosc_wierzcholkow, pomoc_kopia, pom_kopia, j, naj,najlepszy);
                }
            } else if (pomoc_kopia.size()>1) {
                if (graf_do_przeszukania.do_exists_line(pomoc_kopia[pomoc_kopia.size() - 2], j) && j != punkt_startowy && !czy_jest(pomoc_kopia, j)) {
                    if (waga_linii_miedzy_punktami(pomoc_kopia[pomoc_kopia.size() - 2], j, graf_do_przeszukania) == waga_linii_miedzy_punktami(pomoc_kopia[pomoc_kopia.size() - 2], wybor, graf_do_przeszukania)) {
                        funkcja_szukajaca_drogi(graf_do_przeszukania, ilosc_wierzcholkow, pomoc_kopia, pom_kopia, j, naj,najlepszy);
                    }
                } else {
                    if (pomoc_kopia.size() == ilosc_wierzcholkow - 1 && graf_do_przeszukania.do_exists_line(pomoc_kopia[pomoc_kopia.size() - 2], j) && !czy_jest(pomoc_kopia, j)) {
                        if (waga_linii_miedzy_punktami(pomoc_kopia[pomoc_kopia.size() - 2], j, graf_do_przeszukania) == waga_linii_miedzy_punktami(pomoc_kopia[pomoc_kopia.size() - 2], wybor, graf_do_przeszukania)) {
                            funkcja_szukajaca_drogi(graf_do_przeszukania, ilosc_wierzcholkow, pomoc_kopia, pom_kopia, j, naj,najlepszy);
                        }
                    }
                }
            }
        }
    }
}

void random (matrix_graph graf_do_przeszukania, int ilosc_wierzcholkow,std::vector<int>pomoc_kopia, int &naj, std::vector<int> &najlepszy, int opt, int czas_dla_programu_w_s) {
    auto start = std::chrono::high_resolution_clock::now();
    int i;
        while (naj!=opt) {
            int n=0,pom=0;
            int punkt_startowy=rand()%ilosc_wierzcholkow;
            pomoc_kopia.clear();
            while (n<15) {
                i = rand() % ilosc_wierzcholkow;
                while (!pomoc_kopia.empty() && pomoc_kopia[pomoc_kopia.size() - 1] == i) {
                    i = rand() % ilosc_wierzcholkow;
                }
                while(pomoc_kopia.size()!=ilosc_wierzcholkow-1&&i==punkt_startowy) {
                    i=rand()%ilosc_wierzcholkow;
                }
                if ((pomoc_kopia.empty() && graf_do_przeszukania.do_exists_line(punkt_startowy, i)) || (!pomoc_kopia.empty() && graf_do_przeszukania.do_exists_line(pomoc_kopia[pomoc_kopia.size() - 1], i) && !czy_jest(pomoc_kopia, i))) {
                    if (pomoc_kopia.empty()) pom = pom + waga_linii_miedzy_punktami(i, punkt_startowy, graf_do_przeszukania);
                    else {
                        pom = pom + waga_linii_miedzy_punktami(i, pomoc_kopia[pomoc_kopia.size() - 1], graf_do_przeszukania);
                    }
                    pomoc_kopia.push_back(i);
                }else {
                    n++;
                }
                //sprawdzanie czy obszedł wszystkie punkty i wrócił na początek
                if (!pomoc_kopia.empty()&&pomoc_kopia[pomoc_kopia.size()-1] == punkt_startowy && pomoc_kopia.size() == ilosc_wierzcholkow) {
                    if (pom < naj) {
                        naj = pom;
                        najlepszy = pomoc_kopia;
                        break;
                    }
                }
            }
            auto teraz = std::chrono::high_resolution_clock::now();
            auto czas_trwania_programu = std::chrono::duration_cast<std::chrono::seconds>(teraz - start);
            if (czas_trwania_programu.count() >= czas_dla_programu_w_s ) {
                break;
            }
        }
}

int dolna_granica_mst(matrix_graph &graf, int ilosc_wierzcholkow) {
    // Algorytm Prima do wyznaczenia MST
    std::vector<bool> visited(ilosc_wierzcholkow, false);
    std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, std::greater<>> pq;

    // Zaczynamy od pierwszego wierzchołka
    visited[0] = true;
    for (int i = 0; i < ilosc_wierzcholkow; ++i) {
        int waga = waga_linii_miedzy_punktami(0, i,graf);
        if (waga != -99999) {
            pq.push({waga, i});
        }
    }

    int mst_weight = 0;
    while (!pq.empty()) {
        auto [waga, v] = pq.top();
        pq.pop();

        if (visited[v]) continue;

        visited[v] = true;
        mst_weight += waga;

        for (int i = 0; i < ilosc_wierzcholkow; ++i) {
            int next_waga = waga_linii_miedzy_punktami(v, i,graf);
            if (!visited[i] && next_waga != -99999) {
                pq.push({next_waga, i});
            }
        }
    }

    return mst_weight;
}


// Obliczanie błędu bezwzględnego jako liczby
int blad_bezwzgledny(int wynik, int optymalny) {
    return abs(wynik - optymalny);
}

// Obliczanie błędu bezwzględnego jako procent
double blad_bezwzgledny_procent(int wynik, int optymalny) {
    return (static_cast<double>(abs(wynik - optymalny)) / optymalny) * 100.0;
}

// Obliczanie błędu względnego jako liczby
int blad_wzgledny(int wynik, int dolna_granica) {
    return wynik - dolna_granica;
}

// Obliczanie błędu względnego jako procent
double blad_wzgledny_procent(int wynik, int dolna_granica) {
    return (static_cast<double>(wynik - dolna_granica) / dolna_granica) * 100.0;
}

void tabu_search(matrix_graph &graf, int ilosc_wierzcholkow, int limit_czasu_ms, std::vector<int> &najlepszy, int &najlepsza_waga, int opt, int funkcja,int zal) {
    int dolna_granica=dolna_granica_mst(graf,ilosc_wierzcholkow);

    std::vector<int> aktualny_szlak;
    int aktualna_waga = INT_MAX;

    if (funkcja == 0) {
        int pocz=0;
        while(aktualna_waga==INT_MAX&&pocz<ilosc_wierzcholkow) {
            funkcja_szukajaca_drogi(graf, ilosc_wierzcholkow, {}, 0, pocz, aktualna_waga, aktualny_szlak);
            pocz++;
        }
    } else {
        random(graf, ilosc_wierzcholkow, {}, aktualna_waga, aktualny_szlak, opt, funkcja);
    }
    auto start = std::chrono::high_resolution_clock::now();
    auto ostatnia_aktualizacja = start; // Resetowanie czasu na znalezienie nowego rozwiązania

    najlepszy = aktualny_szlak;
    najlepsza_waga = aktualna_waga;

    std::vector<std::vector<int>> lista_tabu;
    int max_dlugosc_listy = ilosc_wierzcholkow * zal; // Wielkość listy tabu zależna od wielkości instancji

    while (true) {
        auto teraz = std::chrono::high_resolution_clock::now();
        auto czas_trwania = std::chrono::duration_cast<std::chrono::milliseconds>(teraz - ostatnia_aktualizacja).count();

        if (czas_trwania > limit_czasu_ms) break;

        std::vector<int> najlepszy_sasiad;
        int najlepsza_waga_sasiada = INT_MAX;

        if(najlepsza_waga==opt) {
            break;
        }

        for (int i = 1; i < ilosc_wierzcholkow - 1; ++i) {
            for (int j = i + 1; j < ilosc_wierzcholkow; ++j) {
                if(aktualny_szlak.empty()) throw std::logic_error("Brak sciezki poczatkowej, jesli korzystasz z algorytmu losowego ustaw wiecej czasu dla niego");
                std::vector<int> sasiad = aktualny_szlak;
                std::swap(sasiad[i], sasiad[j]);

                if (std::find(lista_tabu.begin(), lista_tabu.end(), sasiad) != lista_tabu.end()) continue;

                int waga_sasiada = 0;
                bool droga_poprawna = true;

                for (int k = 0; k < ilosc_wierzcholkow; ++k) {
                    int nast = (k + 1) % ilosc_wierzcholkow;
                    int waga = waga_linii_miedzy_punktami(sasiad[k], sasiad[nast], graf);

                    if (waga == -99999) {
                        droga_poprawna = false; // Przerywamy, jeśli brak drogi
                        break;
                    }
                    waga_sasiada += waga;
                }

                if (droga_poprawna && waga_sasiada < najlepsza_waga_sasiada&& waga_sasiada>= dolna_granica) {
                    najlepsza_waga_sasiada = waga_sasiada;
                    najlepszy_sasiad = sasiad;
                }
            }
        }

        if (najlepsza_waga_sasiada < najlepsza_waga) {
            najlepszy = najlepszy_sasiad;
            najlepsza_waga = najlepsza_waga_sasiada;
            if (najlepsza_waga == opt) break;
            ostatnia_aktualizacja = std::chrono::high_resolution_clock::now(); // Reset czasu po poprawie rozwiązania
        }

        aktualny_szlak = najlepszy_sasiad;
        aktualna_waga = najlepsza_waga_sasiada;

        lista_tabu.push_back(aktualny_szlak);
        if (lista_tabu.size() > max_dlugosc_listy) {
            lista_tabu.erase(lista_tabu.begin());
        }
    }
}

int main() {
    try {
        auto start_programu = std::chrono::high_resolution_clock::now();
        //=========================================
        //int sp = 14, lin =45 ;//całkowicie losowy
        //matrix_graph graf{sp, lin};
        //=========================================

        //=========================================
        std::ifstream odczytus("conf.txt");
        int macierz=0;
        int limit_czasu=0;
        int metoda=0;
        int zaleznosc;
        std::string odczytany_wyraz,nazwa_danych;
        while(true) {
            odczytus>>odczytany_wyraz;
            if(odczytany_wyraz[0]=='/'&&odczytany_wyraz[1]=='/') continue;
            if(odczytany_wyraz[0]=='!') break;
            if(odczytany_wyraz[0]=='M') {
                odczytus>>macierz;
                continue;
            }
            if(odczytany_wyraz[0]=='#') {
                odczytus>>limit_czasu;
            }
            if(odczytany_wyraz[0]=='@') {
                odczytus>>metoda;
            }
            if(odczytany_wyraz[0]=='&') {
                odczytus>>zaleznosc;
            }
            if(odczytany_wyraz.size()>4&&odczytany_wyraz[odczytany_wyraz.size()-1]=='t'&&odczytany_wyraz[odczytany_wyraz.size()-3]=='t') {
                nazwa_danych=odczytany_wyraz;
            }
        }
        if(metoda<0) throw std::logic_error("Blednie podana wartosc dla wybrania funkcji rozwiazania poczatkowego");
        if(limit_czasu==0) throw std::logic_error("brak ustalonego limitu czasu");
        matrix_graph graf(true);
        int sp=-99999;
        std::ifstream odczyt(nazwa_danych);//pliki wrzucać do cmake'a
        int optymalne;
        odczyt>>optymalne;
        if(macierz==1) {
            odczyt>>sp;
            graf.add_splot(sp);
            int punkt2=0,waga=0,n=0;
            while(n<=sp*sp) {
                for(int punkt1=0;punkt1<sp;punkt1++) {
                    odczyt>>waga;
                    if(waga!=-99999) {
                        graf.add_line(punkt1,punkt2,waga);
                    }
                }
                punkt2++;
                n++;
            }
        }else {
            odczyt>>sp;
            graf.add_splot(sp);
            std::vector<std::pair<int, int>> koordynaty(sp);
            while(true){
                int id, x, y;
                odczyt >> id;
                if(id==-99999) break;
                odczyt >> x >> y;
                koordynaty[id - 1] = {x, y};
            }
            for (int i = 0; i < sp; ++i) {
                for (int j = i + 1; j < sp; ++j) {
                    int x1 = koordynaty[i].first, y1 = koordynaty[i].second;
                    int x2 = koordynaty[j].first, y2 = koordynaty[j].second;

                    double dystans = std::sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
                    int zaaokroglony_dystans = static_cast<int>(std::round(dystans));
                    graf.add_line(i,j,zaaokroglony_dystans);
                }
            }
        }
        //=========================================

        if (sp == -99999) throw std::logic_error("brak pliku albo zly format");; //zabezpieczenie przed próbą włączenia programu na pustym grafie
        std::vector<int> najlepszy;
        int naj = INT_MAX;

        tabu_search(graf,sp,limit_czasu,najlepszy,naj,optymalne,metoda,zaleznosc);

        if (naj == INT_MAX) printf("nie istnieje nawet 1 droga pozwalajaca przejsc przez wszystkie punkty");
        else {
        if(sp<=16) {
            printf("\nnajkrotsza droga to: ");
            for (int b = 0; b < najlepszy.size(); b++) {
                printf("%d ", najlepszy[b]);
            }
            printf("%d",najlepszy[0]);
        }
            printf("\ndroga ta wazy: %d ", naj);
            auto czas_teraz = std::chrono::high_resolution_clock::now();
            auto czas = std::chrono::duration_cast<std::chrono::milliseconds>(czas_teraz - start_programu);
            long long int czas_trwania_programu=czas.count();
            czas_trwania_programu-=metoda*1000;
            printf("\nAlgorytm ten trwal: %lld ms \n", czas_trwania_programu);
            std::cout<<"Uzyty plik z danymi to: "<<nazwa_danych;
            if(macierz==1) printf("\nSczytano z macierzy");
            if(macierz==0) printf("\nSczytano linia po linii");
            printf("\nUstawiony limit czasu to: %d ms",limit_czasu);
            printf("\nUstawiona zaleznosc miedzy wierzcholkami to %d ilosc wierzcholkow",zaleznosc);
            if(metoda==0) printf("\nUzyto algorytmu NN jako rozwiazanie poczatkowe");
                else {
                    printf("\nUzyto algorytmu losowego jako rozwiazanie poczatkowe, czas wykonywania losowego zostal ustalony na: %d s",metoda);
                }
            printf("\nOptymalna sciezka to: %d",optymalne);

            int dolna_granica=dolna_granica_mst(graf,sp);
            int blad_bezwzgledny_wynik = blad_bezwzgledny(naj, optymalne);
            double blad_bezwzgledny_proc = blad_bezwzgledny_procent(naj, optymalne);
            int blad_wzgledny_wynik = blad_wzgledny(naj, dolna_granica);
            double blad_wzgledny_proc = blad_wzgledny_procent(naj, dolna_granica);

            printf("\nDolna Granica : %d", dolna_granica);
            printf("\nBlad bezwzgledny (liczba): %d", blad_bezwzgledny_wynik);
            printf("\nBlad bezwzgledny (procent): %.2f%%", blad_bezwzgledny_proc);
            printf("\nBlad wzgledny (liczba): %d", blad_wzgledny_wynik);
            printf("\nBlad wzgledny (procent): %.2f%%", blad_wzgledny_proc);

            if(!std::filesystem::exists("plik_wyjsciowy.csv")) {
                std::ofstream wyjscie;
                wyjscie.open ("plik_wyjsciowy.csv");
                wyjscie<<"wielkosc instancji;"<<"czas wykonywania [ms];"<<"waga znalezionej sciezki;"<<"Blad bezwgledny %;"<<"Blad wzgledny %;"<<"zuzycie RAM [%];"<<std::endl;
                wyjscie<<sp<<";"<<czas_trwania_programu<<";"<<naj<<";"<<blad_bezwzgledny_proc<<";"<<blad_wzgledny_proc<<std::endl;
                wyjscie.close();
            }else {
                std::ofstream wyjscie;
                wyjscie.open ("plik_wyjsciowy.csv",std::ios::app);
                wyjscie<<sp<<";"<<czas_trwania_programu<<";"<<naj<<";"<<blad_bezwzgledny_proc<<";"<<blad_wzgledny_proc<<std::endl;
                wyjscie.close();
            }
        }
    } catch (std::logic_error &e) {
        std::cout << e.what();
    }

    return 0;
}

bool czy_jest(std::vector<int> do_przeszukania, int to) {
    for (int i = 0; i < do_przeszukania.size(); i++) {
        if (do_przeszukania[i] == to) return true;
    }
    return false;
}

int waga_linii_miedzy_punktami(int punkt_1, int punkt_2, matrix_graph &lul) {
    if (lul.weight_of_choosen_line(punkt_1, punkt_2) != -99999 &&
        lul.weight_of_choosen_line(punkt_2, punkt_1) != -99999) {
        if (lul.weight_of_choosen_line(punkt_1, punkt_2) < lul.weight_of_choosen_line(punkt_2, punkt_1)) {
            return lul.weight_of_choosen_line(punkt_1, punkt_2);
        }
        return lul.weight_of_choosen_line(punkt_2, punkt_1);
    }
    if (lul.weight_of_choosen_line(punkt_1, punkt_2) != -99999) return lul.weight_of_choosen_line(punkt_1, punkt_2);
    if (lul.weight_of_choosen_line(punkt_2, punkt_1) != -99999) return lul.weight_of_choosen_line(punkt_2, punkt_1);
    return -99999;
}
